import { Component } from '@angular/core';

@Component({
  selector: 'app-dish-opt',
  templateUrl: './dish-opt.component.html',
  styleUrl: './dish-opt.component.css'
})
export class DishOptComponent {

}
