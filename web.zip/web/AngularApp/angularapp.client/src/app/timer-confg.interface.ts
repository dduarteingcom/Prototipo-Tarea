export interface TimerConfig {
  id: number;
  initialMinutes: number;
  initialSeconds: number;
}
